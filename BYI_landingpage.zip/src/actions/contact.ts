import { createServerFn } from "@tanstack/react-start";
import mongoose from "mongoose";
import * as dotenv from "dotenv";

// Connect strictly to MongoDB using MONGODB_URI from the .env file
const connectDB = async () => {
  if (mongoose.connection.readyState >= 1) return;
  
  dotenv.config();
  const uri = process.env.MONGODB_URI;
  
  if (!uri || uri.includes("your_username") || uri.includes("xxxxxx")) {
    throw new Error(
      "Please insert your real MongoDB connection URI inside the .env file."
    );
  }
  await mongoose.connect(uri);
};

// Define the Schema for a contact submission
const ContactSchema = new mongoose.Schema({
  fullname: { type: String, required: true },
  email: { type: String, required: true },
  company: { type: String, required: false },
  phone: { type: String, required: true },
  message: { type: String, required: false },
  status: {
    type: String,
    enum: ["New", "Contacted", "Interested", "Converted"],
    default: "New",
  },
  pushedToMainStore: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

// Define Schema matching the main website's Lead model (collection: "leads")
const MainWebsiteLeadSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  subject: { type: String, required: true },
  message: { type: String },
  status: { type: String, default: "discovery" },
  createdAt: { type: Date, default: Date.now }
}, { collection: "leads" });

// Prevent Mongoose from recompiling models upon hot-reloads
const ContactModel = mongoose.models.Contact || mongoose.model("Contact", ContactSchema);
const MainWebsiteLeadModel = mongoose.models.MainWebsiteLead || mongoose.model("MainWebsiteLead", MainWebsiteLeadSchema);

// Create a secure server function (API) to handle form submissions
export const submitContactForm = createServerFn({ method: "POST" })
  .validator((data: { fullname: string; email: string; company?: string; phone: string; message?: string }) => {
    const cleanPhone = data.phone?.replace(/\D/g, "");
    if (!cleanPhone || cleanPhone.length !== 10) {
      throw new Error("Phone number must be exactly 10 digits");
    }
    return { ...data, phone: cleanPhone };
  })
  .handler(async ({ data }) => {
    try {
      await connectDB();

      const newContact = new ContactModel({
        fullname: data.fullname,
        email: data.email,
        company: data.company || "",
        phone: data.phone,
        message: data.message || "",
        status: "New",
        pushedToMainStore: false,
      });
      await newContact.save();
      return { success: true };
    } catch (error: any) {
      console.error("Submission Error:", error);
      throw new Error(error.message || "Failed to save submission to MongoDB");
    }
  });

// Server function to verify admin password
export const verifyAdminAuth = createServerFn({ method: "POST" })
  .validator((data: { password: string }) => data)
  .handler(async ({ data }) => {
    const adminPass = process.env.ADMIN_PASSWORD || "byi2026";
    if (data.password === adminPass) {
      return { success: true };
    }
    throw new Error("Invalid admin password");
  });

// Server function to fetch all leads for the admin dashboard (Protected)
export const getLeads = createServerFn({ method: "POST" })
  .validator((data: { password: string }) => data)
  .handler(async ({ data }) => {
    const adminPass = process.env.ADMIN_PASSWORD || "byi2026";
    if (!data || data.password !== adminPass) {
      throw new Error("Unauthorized access to portal");
    }
    try {
      await connectDB();
      const leads = await ContactModel.find().sort({ createdAt: -1 }).lean();
      return leads.map((lead: any) => ({
        _id: lead._id.toString(),
        fullname: lead.fullname,
        email: lead.email,
        phone: lead.phone,
        company: lead.company || "",
        message: lead.message || "",
        status: lead.status || "New",
        pushedToMainStore: lead.pushedToMainStore || false,
        createdAt: lead.createdAt.toISOString(),
      }));
    } catch (error) {
      console.error("Failed to fetch leads from MongoDB:", error);
      return [];
    }
  });

// Server function to update status and automatically push to main store database when Converted/Interested (Protected)
export const updateLeadStatus = createServerFn({ method: "POST" })
  .validator((data: { id: string; status: "New" | "Contacted" | "Interested" | "Converted"; password: string }) => data)
  .handler(async ({ data }) => {
    const adminPass = process.env.ADMIN_PASSWORD || "byi2026";
    if (!data || data.password !== adminPass) {
      throw new Error("Unauthorized access");
    }
    try {
      await connectDB();

      const lead = await ContactModel.findById(data.id);
      if (!lead) throw new Error("Lead not found");

      lead.status = data.status;

      if (data.status === "Interested" || data.status === "Converted") {
        lead.pushedToMainStore = true;

        const subjectText = lead.company 
          ? `Meta Ads Lead: ${lead.company} (${lead.phone}) [${data.status}]`
          : `Meta Ads Lead (${lead.phone}) [${data.status}]`;

        const messageText = `[Meta Ad Inquiry]\nPhone: ${lead.phone}\nCompany: ${lead.company || "N/A"}\nStatus: ${data.status}\nMessage: ${lead.message || "No details provided"}`;

        const mainStatus = data.status === "Converted" ? "working" : "discovery";

        await MainWebsiteLeadModel.findOneAndUpdate(
          { email: lead.email, subject: { $regex: lead.phone } },
          {
            name: lead.fullname,
            email: lead.email,
            subject: subjectText,
            message: messageText,
            status: mainStatus,
            createdAt: new Date(),
          },
          { upsert: true, new: true }
        );

        if (process.env.MAIN_STORE_WEBHOOK_URL) {
          try {
            await fetch(process.env.MAIN_STORE_WEBHOOK_URL, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                event: "lead_converted",
                lead: {
                  id: lead._id.toString(),
                  fullname: lead.fullname,
                  email: lead.email,
                  phone: lead.phone,
                  company: lead.company,
                  status: data.status,
                },
              }),
            });
          } catch (webhookErr) {
            console.error("Webhook push failed:", webhookErr);
          }
        }
      }

      await lead.save();
      return { success: true, status: lead.status, pushedToMainStore: lead.pushedToMainStore };
    } catch (error) {
      console.error("Failed to update lead status:", error);
      throw new Error("Failed to update lead status in MongoDB");
    }
  });

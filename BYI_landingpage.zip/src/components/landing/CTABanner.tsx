import { motion } from "motion/react";

export function CTABanner() {
  return (
    <section className="relative overflow-hidden py-20 md:py-32" style={{ background: "#0d0d10" }}>
      {/* ── Background video ── */}
      <div className="pointer-events-none absolute inset-0 z-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="h-full w-full object-cover opacity-25"
          style={{ mixBlendMode: "screen" }}
        >
          <source
            src="https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-network-animation-5798-large.mp4"
            type="video/mp4"
          />
        </video>
        {/* Gradient overlay so text stays readable */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0d0d10] via-transparent to-[#0d0d10]" />
      </div>

      {/* subtle center ambient glow */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center z-0">
        <div className="h-[350px] w-[700px] rounded-full bg-[#7E52D9]/25 blur-[120px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
        className="relative z-10 mx-auto max-w-4xl px-6 text-center"
      >
        <h2 className="font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl leading-tight">
          Build Your online presence <span className="bg-gradient-to-r from-[#C49EFF] via-[#E0CFFF] to-white bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(168,130,255,0.5)]">TODAY!</span>
        </h2>
        
        <div className="mt-10 flex justify-center">
          <a
            href="#contact"
            className="group relative inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-gradient-to-r from-[#7E52D9] via-[#8A5CF5] to-[#A882FF] px-10 py-4 text-base font-bold text-white shadow-[0_0_30px_rgba(138,92,245,0.6)] transition-all duration-300 hover:scale-105 hover:shadow-[0_0_50px_rgba(168,130,255,0.9)] hover:border-white/40"
          >
            <span>Contact Us</span>
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="transition-transform duration-300 group-hover:translate-x-1"
            >
              <line x1="5" y1="12" x2="19" y2="12" />
              <polyline points="12 5 19 12 12 19" />
            </svg>
          </a>
        </div>
      </motion.div>
    </section>
  );
}
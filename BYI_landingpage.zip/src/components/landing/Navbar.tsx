import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import logo from "@/assets/logo.png";

const links = [
  { label: "Home", href: "#home", num: "01" },
  { label: "About", href: "#about", num: "02" },
  { label: "Services", href: "#services", num: "03" },
  { label: "Process", href: "#process", num: "04" },
  { label: "Contact", href: "#contact", num: "05" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed left-0 right-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? "backdrop-blur-xl bg-[#0b0516]/90 border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.5)]" : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3.5 md:px-10">
        <a href="#home" className="flex items-center gap-2.5 font-display tracking-tight group">
          <div className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl bg-gradient-to-br from-white/20 to-white/5 border border-white/20 shadow-[0_0_15px_rgba(168,130,255,0.3)] group-hover:scale-105 transition-transform shrink-0 p-1">
            <img
              src={logo}
              alt="Beyond Your Imagination Logo"
              className="h-full w-full object-contain"
              style={{ filter: "brightness(1.25) drop-shadow(0 0 6px rgba(255,255,255,0.4))" }}
            />
          </div>
          <span className="text-white text-sm sm:text-base font-extrabold tracking-tight leading-none">
            Beyond Your <span className="text-[#C49EFF]">Imagination</span>
          </span>
        </a>
        <ul className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="text-sm font-medium text-white/80 transition-colors hover:text-white">
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <div className="hidden md:flex items-center gap-3">
          <a
            href="https://beyondyourimagination.shop"
            className="inline-flex items-center gap-1.5 rounded-[10px] border border-white/20 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/15 hover:border-white/40"
          >
            <span>Main Website</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3" />
            </svg>
          </a>
          <a
            href="#contact"
            className="btn-glow inline-flex items-center justify-center rounded-[10px] bg-white px-5 py-2.5 text-sm font-semibold text-black"
          >
            Get Started
          </a>
        </div>
        <button
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
          className={`md:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl border transition-all duration-300 ${
            open
              ? "border-[#A882FF] bg-[#A882FF]/20 text-white shadow-[0_0_15px_rgba(168,130,255,0.5)]"
              : "border-white/15 bg-white/5 text-white/90 hover:border-white/30"
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? <path strokeLinecap="round" strokeLinejoin="round" d="M6 6l12 12M6 18L18 6" /> : <path strokeLinecap="round" strokeLinejoin="round" d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </nav>

      {/* ── Luxury Mobile Navigation Menu ── */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: "easeInOut" }}
            className="md:hidden overflow-hidden border-t border-b border-white/10 bg-[#0a0414]/95 backdrop-blur-2xl shadow-[0_25px_60px_rgba(0,0,0,0.8)]"
          >
            <div className="px-6 py-6 space-y-3">
              <div className="text-[10px] font-bold uppercase tracking-widest text-[#C49EFF]/80 px-1 mb-2">
                Navigation Menu
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                {links.map((l) => (
                  <a
                    key={l.href}
                    onClick={() => setOpen(false)}
                    href={l.href}
                    className="group flex items-center justify-between rounded-2xl border border-white/5 bg-white/[0.03] px-4 py-3.5 text-sm font-semibold text-white/90 transition-all duration-200 active:scale-[0.98] hover:border-[#A882FF]/50 hover:bg-[#A882FF]/15 hover:text-white hover:shadow-[0_0_20px_rgba(168,130,255,0.2)]"
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="text-base tracking-tight">{l.label}</span>
                    </div>
                    <svg
                      className="h-4 w-4 text-white/40 transition-all duration-200 group-hover:translate-x-1 group-hover:text-[#C49EFF]"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                    </svg>
                  </a>
                ))}
              </div>

              <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
                <a
                  onClick={() => setOpen(false)}
                  href="https://beyondyourimagination.shop"
                  className="flex items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/5 px-5 py-3.5 text-center text-sm font-bold text-white transition-all active:scale-[0.98] hover:bg-white/10 hover:border-white/40"
                >
                  <span>Visit Main Store</span>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3" />
                  </svg>
                </a>
                <a
                  onClick={() => setOpen(false)}
                  href="#contact"
                  className="flex items-center justify-center rounded-2xl bg-gradient-to-r from-white via-white to-[#E0CFFF] px-5 py-3.5 text-center text-sm font-extrabold text-black shadow-[0_0_30px_rgba(255,255,255,0.3)] transition-all active:scale-[0.98]"
                >
                  Start Your Project
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
import logo from "@/assets/logo.png";

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/10 pt-16 pb-12 text-white" style={{ background: "#0b0b0e" }}>
      {/* ── Ambient Glows ── */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[300px] w-[800px] -translate-x-1/2 rounded-full bg-[#7E52D9]/15 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-6 md:px-10">
        
        {/* ── Top Call-to-Action Glass Banner ── */}
        <div className="mb-16 rounded-3xl border border-white/15 bg-gradient-to-r from-white/[0.07] via-[#8A5CF5]/10 to-white/[0.05] p-8 sm:p-10 backdrop-blur-xl shadow-[0_0_60px_rgba(138,92,245,0.12)] flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="pointer-events-none absolute -right-10 -bottom-10 h-40 w-40 rounded-full bg-[#A882FF]/20 blur-2xl" />
          
          <div className="text-center md:text-left z-10">
            <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-2">Next-Generation Digital Agency</span>
            <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white">Ready to elevate your digital presence?</h3>
            <p className="mt-1 text-sm text-white/70 max-w-lg">Let's collaborate to build cutting-edge AI software and breathtaking web experiences tailored to your vision.</p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3.5 z-10 shrink-0">
            <a
              href="https://beyondyourimagination.shop"
              className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-semibold text-white backdrop-blur transition-all hover:bg-white/20 hover:border-white/40"
            >
              <span>Visit Main Store</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3" />
              </svg>
            </a>
            <a
              href="#contact"
              className="inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-white via-white to-[#E0CFFF] px-6 py-3 text-sm font-bold text-black shadow-[0_0_25px_rgba(255,255,255,0.25)] transition-all hover:shadow-[0_0_40px_rgba(168,130,255,0.6)] hover:-translate-y-0.5"
            >
              Start Your Project
            </a>
          </div>
        </div>

        {/* ── Main Footer Navigation Grid ── */}
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-8">
          
          {/* Brand Info (4 cols on desktop) */}
          <div className="lg:col-span-4 flex flex-col items-center sm:items-start text-center sm:text-left justify-between">
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2.5">
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-xl bg-gradient-to-br from-white/20 to-white/5 border border-white/20 shadow-[0_0_15px_rgba(168,130,255,0.3)] shrink-0 p-1">
                  <img
                    src={logo}
                    alt="Beyond Your Imagination Logo"
                    className="h-full w-full object-contain"
                    style={{ filter: "brightness(1.25) drop-shadow(0 0 6px rgba(255,255,255,0.4))" }}
                  />
                </div>
                <span className="font-display text-base sm:text-lg font-extrabold text-white tracking-tight leading-none">
                  Beyond Your <span className="text-[#C49EFF]">Imagination</span>
                </span>
              </div>
              <p className="mt-3 sm:mt-4 max-w-sm text-xs sm:text-sm leading-relaxed text-white/60 mx-auto sm:mx-0">
                Architecting luxury digital products, AI solutions, and high-conversion web ecosystems that push boundaries beyond imagination.
              </p>
            </div>

            <div className="mt-5 sm:mt-6">
              <a
                href="mailto:support@beyondyourimagination.shop"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-xs font-medium text-white/80 hover:border-white/25 hover:text-[#C49EFF] transition-colors break-all sm:break-normal max-w-full"
              >
                <svg className="shrink-0" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <span>support@beyondyourimagination.shop</span>
              </a>
            </div>
          </div>

          {/* Side-by-side grid on mobile for Navigation & Ecosystem (5 cols on desktop) */}
          <div className="grid grid-cols-2 gap-6 sm:gap-8 lg:col-span-5 lg:pl-6 text-center sm:text-left">
            {/* Navigation Links */}
            <div className="flex flex-col items-center sm:items-start">
              <h4 className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-3.5">Navigation</h4>
              <ul className="space-y-2.5 text-xs sm:text-sm font-medium text-white/70 flex flex-col items-center sm:items-start">
                {["Home", "About", "Services", "Process", "Contact"].map((item) => (
                  <li key={item}>
                    <a
                      href={`#${item.toLowerCase()}`}
                      className="group inline-flex items-center justify-center sm:justify-start gap-1.5 hover:text-white transition-colors"
                    >
                      <span className="text-[#A882FF] opacity-60 group-hover:opacity-100 transition-opacity">›</span>
                      <span>{item}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Ecosystem Links */}
            <div className="flex flex-col items-center sm:items-start">
              <h4 className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-3.5">Ecosystem</h4>
              <ul className="space-y-2.5 text-xs sm:text-sm font-medium text-white/70 flex flex-col items-center sm:items-start">
                <li>
                  <a href="https://beyondyourimagination.shop" className="hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1 group">
                    <span className="text-[#A882FF] opacity-60 group-hover:opacity-100 transition-opacity">›</span>
                    <span>Main Website</span>
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3" />
                    </svg>
                  </a>
                </li>
                <li><a href="#services" className="hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1"><span className="text-[#A882FF] opacity-60">›</span> AI Engineering</a></li>
                <li><a href="#services" className="hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1"><span className="text-[#A882FF] opacity-60">›</span> UI/UX Design</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1"><span className="text-[#A882FF] opacity-60">›</span> Client Support</a></li>
              </ul>
            </div>
          </div>

          {/* Social Connect (3 cols on desktop) */}
          <div className="lg:col-span-3 flex flex-col items-center sm:items-start text-center sm:text-left">
            <h4 className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-3.5">Connect With Us</h4>
            <p className="text-xs text-white/60 mb-4 leading-relaxed max-w-xs mx-auto sm:mx-0">Follow our latest work, insights, and innovations across social media.</p>
            
            <div className="flex items-center justify-center sm:justify-start gap-3">
              {/* Instagram */}
              <a
                href="https://www.instagram.com/byi_agency/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-white/80 transition-all duration-300 hover:scale-110 hover:border-[#A882FF] hover:bg-[#A882FF]/20 hover:text-white hover:shadow-[0_0_20px_rgba(168,130,255,0.5)]"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                </svg>
              </a>

              {/* Facebook */}
              <a
                href="https://www.facebook.com/profile.php?fb_profile_edit_entry_point=%7B%22click_point%22%3A%22edit_profile_button%22%2C%22feature%22%3A%22profile_header%22%7D&id=61591354119710&sk=about"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-white/80 transition-all duration-300 hover:scale-110 hover:border-[#A882FF] hover:bg-[#A882FF]/20 hover:text-white hover:shadow-[0_0_20px_rgba(168,130,255,0.5)]"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
            </div>
          </div>

        </div>

        {/* ── Bottom Copyright Bar ── */}
        <div className="mt-12 sm:mt-14 border-t border-white/10 pt-6 sm:pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left text-xs font-medium text-white/50">
          <div>
            © {new Date().getFullYear()} Beyond Your Imagination. All rights reserved.
          </div>
          <div className="flex flex-wrap items-center justify-center gap-5 sm:gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Security</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-D-fSknPv.js
var manifest = {
	"4791d1765c9018fdebb29c0efbd58e5e1711e4743b058ce7455d73dad5884a6e": {
		functionName: "verifyAdminAuth_createServerFn_handler",
		importer: () => import("./_ssr/contact-5kJtMb3r.mjs")
	},
	"4d0e05268a603875317a5113fa9eded1af11ddcd2ad1205d38fe8196605dae7e": {
		functionName: "submitContactForm_createServerFn_handler",
		importer: () => import("./_ssr/contact-5kJtMb3r.mjs")
	},
	"4f53c207501d4b162bbfdf5f3882f657907c833cf629270a0c1bb06ae3b94ffd": {
		functionName: "getLeads_createServerFn_handler",
		importer: () => import("./_ssr/contact-5kJtMb3r.mjs")
	},
	"9e6df912563b5e8f5318f93ce9c19aab0e6abfbd1bd3818331fecbaf7ca52eff": {
		functionName: "updateLeadStatus_createServerFn_handler",
		importer: () => import("./_ssr/contact-5kJtMb3r.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };

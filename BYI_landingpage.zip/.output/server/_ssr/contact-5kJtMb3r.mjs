import { o as __toESM } from "../_runtime.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-BfDQLD5K.mjs";
import { t as require_mongoose } from "../_libs/mongoose+mpath+mquery+ms+sift.mjs";
import { t as require_main } from "../_libs/dotenv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-5kJtMb3r.js
var import_mongoose = /* @__PURE__ */ __toESM(require_mongoose());
var import_main = /* @__PURE__ */ __toESM(require_main());
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var connectDB = async () => {
	if (import_mongoose.default.connection.readyState >= 1) return;
	import_main.config();
	const uri = process.env.MONGODB_URI;
	if (!uri || uri.includes("your_username") || uri.includes("xxxxxx")) throw new Error("Please insert your real MongoDB connection URI inside the .env file.");
	await import_mongoose.default.connect(uri);
};
var ContactSchema = new import_mongoose.default.Schema({
	fullname: {
		type: String,
		required: true
	},
	email: {
		type: String,
		required: true
	},
	company: {
		type: String,
		required: false
	},
	phone: {
		type: String,
		required: true
	},
	message: {
		type: String,
		required: false
	},
	status: {
		type: String,
		enum: [
			"New",
			"Contacted",
			"Interested",
			"Converted"
		],
		default: "New"
	},
	pushedToMainStore: {
		type: Boolean,
		default: false
	},
	createdAt: {
		type: Date,
		default: Date.now
	}
});
var MainWebsiteLeadSchema = new import_mongoose.default.Schema({
	name: {
		type: String,
		required: true
	},
	email: {
		type: String,
		required: true
	},
	subject: {
		type: String,
		required: true
	},
	message: { type: String },
	status: {
		type: String,
		default: "discovery"
	},
	createdAt: {
		type: Date,
		default: Date.now
	}
}, { collection: "leads" });
var ContactModel = import_mongoose.default.models.Contact || import_mongoose.default.model("Contact", ContactSchema);
var MainWebsiteLeadModel = import_mongoose.default.models.MainWebsiteLead || import_mongoose.default.model("MainWebsiteLead", MainWebsiteLeadSchema);
var submitContactForm_createServerFn_handler = createServerRpc({
	id: "4d0e05268a603875317a5113fa9eded1af11ddcd2ad1205d38fe8196605dae7e",
	name: "submitContactForm",
	filename: "src/actions/contact.ts"
}, (opts) => submitContactForm.__executeServer(opts));
var submitContactForm = createServerFn({ method: "POST" }).validator((data) => {
	const cleanPhone = data.phone?.replace(/\D/g, "");
	if (!cleanPhone || cleanPhone.length !== 10) throw new Error("Phone number must be exactly 10 digits");
	return {
		...data,
		phone: cleanPhone
	};
}).handler(submitContactForm_createServerFn_handler, async ({ data }) => {
	try {
		await connectDB();
		await new ContactModel({
			fullname: data.fullname,
			email: data.email,
			company: data.company || "",
			phone: data.phone,
			message: data.message || "",
			status: "New",
			pushedToMainStore: false
		}).save();
		return { success: true };
	} catch (error) {
		console.error("Submission Error:", error);
		throw new Error(error.message || "Failed to save submission to MongoDB");
	}
});
var verifyAdminAuth_createServerFn_handler = createServerRpc({
	id: "4791d1765c9018fdebb29c0efbd58e5e1711e4743b058ce7455d73dad5884a6e",
	name: "verifyAdminAuth",
	filename: "src/actions/contact.ts"
}, (opts) => verifyAdminAuth.__executeServer(opts));
var verifyAdminAuth = createServerFn({ method: "POST" }).validator((data) => data).handler(verifyAdminAuth_createServerFn_handler, async ({ data }) => {
	const adminPass = process.env.ADMIN_PASSWORD || "byi2026";
	if (data.password === adminPass) return { success: true };
	throw new Error("Invalid admin password");
});
var getLeads_createServerFn_handler = createServerRpc({
	id: "4f53c207501d4b162bbfdf5f3882f657907c833cf629270a0c1bb06ae3b94ffd",
	name: "getLeads",
	filename: "src/actions/contact.ts"
}, (opts) => getLeads.__executeServer(opts));
var getLeads = createServerFn({ method: "POST" }).validator((data) => data).handler(getLeads_createServerFn_handler, async ({ data }) => {
	const adminPass = process.env.ADMIN_PASSWORD || "byi2026";
	if (!data || data.password !== adminPass) throw new Error("Unauthorized access to portal");
	try {
		await connectDB();
		return (await ContactModel.find().sort({ createdAt: -1 }).lean()).map((lead) => ({
			_id: lead._id.toString(),
			fullname: lead.fullname,
			email: lead.email,
			phone: lead.phone,
			company: lead.company || "",
			message: lead.message || "",
			status: lead.status || "New",
			pushedToMainStore: lead.pushedToMainStore || false,
			createdAt: lead.createdAt.toISOString()
		}));
	} catch (error) {
		console.error("Failed to fetch leads from MongoDB:", error);
		return [];
	}
});
var updateLeadStatus_createServerFn_handler = createServerRpc({
	id: "9e6df912563b5e8f5318f93ce9c19aab0e6abfbd1bd3818331fecbaf7ca52eff",
	name: "updateLeadStatus",
	filename: "src/actions/contact.ts"
}, (opts) => updateLeadStatus.__executeServer(opts));
var updateLeadStatus = createServerFn({ method: "POST" }).validator((data) => data).handler(updateLeadStatus_createServerFn_handler, async ({ data }) => {
	const adminPass = process.env.ADMIN_PASSWORD || "byi2026";
	if (!data || data.password !== adminPass) throw new Error("Unauthorized access");
	try {
		await connectDB();
		const lead = await ContactModel.findById(data.id);
		if (!lead) throw new Error("Lead not found");
		lead.status = data.status;
		if (data.status === "Interested" || data.status === "Converted") {
			lead.pushedToMainStore = true;
			const subjectText = lead.company ? `Meta Ads Lead: ${lead.company} (${lead.phone}) [${data.status}]` : `Meta Ads Lead (${lead.phone}) [${data.status}]`;
			const messageText = `[Meta Ad Inquiry]\nPhone: ${lead.phone}\nCompany: ${lead.company || "N/A"}\nStatus: ${data.status}\nMessage: ${lead.message || "No details provided"}`;
			const mainStatus = data.status === "Converted" ? "working" : "discovery";
			await MainWebsiteLeadModel.findOneAndUpdate({
				email: lead.email,
				subject: { $regex: lead.phone }
			}, {
				name: lead.fullname,
				email: lead.email,
				subject: subjectText,
				message: messageText,
				status: mainStatus,
				createdAt: /* @__PURE__ */ new Date()
			}, {
				upsert: true,
				new: true
			});
			if (process.env.MAIN_STORE_WEBHOOK_URL) try {
				await fetch(process.env.MAIN_STORE_WEBHOOK_URL, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
						event: "lead_converted",
						lead: {
							id: lead._id.toString(),
							fullname: lead.fullname,
							email: lead.email,
							phone: lead.phone,
							company: lead.company,
							status: data.status
						}
					})
				});
			} catch (webhookErr) {
				console.error("Webhook push failed:", webhookErr);
			}
		}
		await lead.save();
		return {
			success: true,
			status: lead.status,
			pushedToMainStore: lead.pushedToMainStore
		};
	} catch (error) {
		console.error("Failed to update lead status:", error);
		throw new Error("Failed to update lead status in MongoDB");
	}
});
//#endregion
export { getLeads_createServerFn_handler, submitContactForm_createServerFn_handler, updateLeadStatus_createServerFn_handler, verifyAdminAuth_createServerFn_handler };

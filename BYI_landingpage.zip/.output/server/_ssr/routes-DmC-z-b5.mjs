import { o as __toESM } from "../_runtime.mjs";
import { n as submitContactForm } from "./contact--Ca3KR-h.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as logo_default } from "./logo-aqA3rk2Z.mjs";
import { n as AnimatePresence } from "../_libs/framer-motion.mjs";
import { t as motion } from "../_libs/motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DmC-z-b5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		label: "Home",
		href: "#home",
		num: "01"
	},
	{
		label: "About",
		href: "#about",
		num: "02"
	},
	{
		label: "Services",
		href: "#services",
		num: "03"
	},
	{
		label: "Process",
		href: "#process",
		num: "04"
	},
	{
		label: "Contact",
		href: "#contact",
		num: "05"
	}
];
function Navbar() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 30);
		onScroll();
		window.addEventListener("scroll", onScroll);
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.header, {
		initial: {
			y: -40,
			opacity: 0
		},
		animate: {
			y: 0,
			opacity: 1
		},
		transition: {
			duration: .6,
			ease: "easeOut"
		},
		className: `fixed left-0 right-0 top-0 z-50 transition-all duration-300 ${scrolled ? "backdrop-blur-xl bg-[#0b0516]/90 border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.5)]" : "bg-transparent"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-3.5 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#home",
					className: "flex items-center gap-2.5 font-display tracking-tight group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl bg-gradient-to-br from-white/20 to-white/5 border border-white/20 shadow-[0_0_15px_rgba(168,130,255,0.3)] group-hover:scale-105 transition-transform shrink-0 p-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo_default,
							alt: "Beyond Your Imagination Logo",
							className: "h-full w-full object-contain",
							style: { filter: "brightness(1.25) drop-shadow(0 0 6px rgba(255,255,255,0.4))" }
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-white text-sm sm:text-base font-extrabold tracking-tight leading-none",
						children: ["Beyond Your ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[#C49EFF]",
							children: "Imagination"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "hidden items-center gap-8 md:flex",
					children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: l.href,
						className: "text-sm font-medium text-white/80 transition-colors hover:text-white",
						children: l.label
					}) }, l.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden md:flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "https://beyondyourimagination.shop",
						className: "inline-flex items-center gap-1.5 rounded-[10px] border border-white/20 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white/15 hover:border-white/40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Main Website" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							width: "14",
							height: "14",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#contact",
						className: "btn-glow inline-flex items-center justify-center rounded-[10px] bg-white px-5 py-2.5 text-sm font-semibold text-black",
						children: "Get Started"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Toggle menu",
					onClick: () => setOpen((v) => !v),
					className: `md:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl border transition-all duration-300 ${open ? "border-[#A882FF] bg-[#A882FF]/20 text-white shadow-[0_0_15px_rgba(168,130,255,0.5)]" : "border-white/15 bg-white/5 text-white/90 hover:border-white/30"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						width: "20",
						height: "20",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							strokeLinecap: "round",
							strokeLinejoin: "round",
							d: "M6 6l12 12M6 18L18 6"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							strokeLinecap: "round",
							strokeLinejoin: "round",
							d: "M4 7h16M4 12h16M4 17h16"
						})
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: {
				height: 0,
				opacity: 0
			},
			animate: {
				height: "auto",
				opacity: 1
			},
			exit: {
				height: 0,
				opacity: 0
			},
			transition: {
				duration: .35,
				ease: "easeInOut"
			},
			className: "md:hidden overflow-hidden border-t border-b border-white/10 bg-[#0a0414]/95 backdrop-blur-2xl shadow-[0_25px_60px_rgba(0,0,0,0.8)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-6 py-6 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] font-bold uppercase tracking-widest text-[#C49EFF]/80 px-1 mb-2",
						children: "Navigation Menu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-2.5",
						children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							onClick: () => setOpen(false),
							href: l.href,
							className: "group flex items-center justify-between rounded-2xl border border-white/5 bg-white/[0.03] px-4 py-3.5 text-sm font-semibold text-white/90 transition-all duration-200 active:scale-[0.98] hover:border-[#A882FF]/50 hover:bg-[#A882FF]/15 hover:text-white hover:shadow-[0_0_20px_rgba(168,130,255,0.2)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-3.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base tracking-tight",
									children: l.label
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								className: "h-4 w-4 text-white/40 transition-all duration-200 group-hover:translate-x-1 group-hover:text-[#C49EFF]",
								fill: "none",
								viewBox: "0 0 24 24",
								stroke: "currentColor",
								strokeWidth: 2,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									d: "M9 5l7 7-7 7"
								})
							})]
						}, l.href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4 border-t border-white/10 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							onClick: () => setOpen(false),
							href: "https://beyondyourimagination.shop",
							className: "flex items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/5 px-5 py-3.5 text-center text-sm font-bold text-white transition-all active:scale-[0.98] hover:bg-white/10 hover:border-white/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Visit Main Store" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "15",
								height: "15",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							onClick: () => setOpen(false),
							href: "#contact",
							className: "flex items-center justify-center rounded-2xl bg-gradient-to-r from-white via-white to-[#E0CFFF] px-5 py-3.5 text-center text-sm font-extrabold text-black shadow-[0_0_30px_rgba(255,255,255,0.3)] transition-all active:scale-[0.98]",
							children: "Start Your Project"
						})]
					})
				]
			})
		}) })]
	});
}
var hero_default = "/assets/hero-DTDr5k5q.png";
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "home",
		className: "relative overflow-hidden min-h-screen flex items-center pt-24 pb-12 md:pt-24 md:pb-16",
		style: { background: "#0d0d10" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 z-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					autoPlay: true,
					muted: true,
					loop: true,
					playsInline: true,
					className: "h-full w-full object-cover opacity-25",
					style: { mixBlendMode: "screen" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
						src: "https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-network-animation-5798-large.mp4",
						type: "video/mp4"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-[#0d0d10] via-[#0d0d10]/85 to-[#0d0d10]/30" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute right-0 top-0 h-full w-2/3 z-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-0 h-full w-full bg-gradient-to-l from-[#5d28ab]/80 via-[#351375]/45 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-1/4 top-1/3 h-[600px] w-[600px] rounded-full bg-[#8A5CF5]/30 blur-[130px]" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto grid max-w-7xl w-full grid-cols-1 items-center gap-8 px-6 md:grid-cols-2 md:px-10 -mt-4 md:-mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 30
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .8,
						ease: "easeOut"
					},
					className: "order-2 text-center md:order-1 md:text-left -mt-6 md:-mt-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 px-3 py-1.5 mb-3.5 rounded-full border border-white/15 bg-white/5 backdrop-blur-md shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#A882FF] animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold tracking-wide text-white/80 uppercase",
								children: "Next-Gen Digital Studio"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-4xl sm:text-5xl lg:text-[56px] xl:text-[66px] font-extrabold leading-[1.05] tracking-tight text-white",
							children: [
								"Crafting the ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "bg-gradient-to-r from-white via-white/95 to-[#A882FF] bg-clip-text text-transparent",
									children: "Future of"
								}),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "whitespace-nowrap",
									children: "Digital Brands."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-lg text-sm sm:text-base text-white/70 mx-auto md:mx-0 leading-relaxed font-normal",
							children: "Premium web experiences powered by state-of-the-art design, modern engineering, and futuristic AI innovation."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col sm:flex-row items-center gap-3.5 justify-center md:justify-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#contact",
								className: "group inline-flex w-full sm:w-auto items-center justify-center gap-2.5 rounded-full bg-white px-7 py-3.5 text-base font-bold text-black shadow-[0_0_30px_rgba(255,255,255,0.25)] transition-all duration-300 hover:bg-white/90 hover:shadow-[0_0_45px_rgba(168,130,255,0.5)] hover:-translate-y-0.5",
								children: ["Get Started", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									className: "h-4 w-4 transition-transform duration-300 group-hover:translate-x-1",
									fill: "none",
									viewBox: "0 0 24 24",
									stroke: "currentColor",
									strokeWidth: 2.5,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										d: "M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "https://beyondyourimagination.shop",
								className: "inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 py-3.5 text-base font-semibold text-white/90 backdrop-blur-md transition-all duration-300 hover:border-white/30 hover:bg-white/10 hover:text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Visit Main Website" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									width: "15",
									height: "15",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"
									})
								})]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						scale: .95
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					transition: {
						duration: 1,
						ease: "easeOut",
						delay: .2
					},
					className: "order-1 md:order-2 relative flex items-center justify-center md:justify-end border-0 outline-none",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
						src: hero_default,
						alt: "Futuristic AI robot head",
						className: "w-64 max-w-full sm:w-80 md:w-full md:max-w-[460px] lg:max-w-[500px] object-contain object-right-bottom select-none border-0 outline-none ring-0 shadow-none",
						style: {
							filter: "drop-shadow(0 0 60px rgba(138,92,245,0.65))",
							maskImage: "radial-gradient(ellipse 88% 88% at center, black 65%, transparent 98%)",
							WebkitMaskImage: "radial-gradient(ellipse 88% 88% at center, black 65%, transparent 98%)",
							mixBlendMode: "lighten"
						},
						animate: { y: [
							0,
							-12,
							0
						] },
						transition: {
							duration: 6,
							repeat: Infinity,
							ease: "easeInOut"
						}
					})
				})]
			})
		]
	});
}
var secondimg_default = "/assets/secondimg-DABLjMbT.png";
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "about",
		className: "relative bg-[#7E52D9] py-16 md:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-0 top-0 h-full w-1/3 bg-gradient-to-r from-[#1a0533]/60 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-6 md:grid-cols-[1fr_auto_1fr] md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 30
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: {
						once: true,
						amount: .3
					},
					transition: { duration: .7 },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl font-extrabold leading-tight tracking-tight text-black sm:text-5xl",
							children: [
								"Building Digital",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Excellence"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm leading-relaxed text-black/80 md:text-base",
							children: "We believe great technology should be powerful, intuitive, and beautifully designed. As a modern technology studio, we partner with ambitious businesses to create digital experiences that inspire trust and drive measurable growth."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-black/80 md:text-base",
							children: "Our expertise spans web development, mobile application development, DevOps, AI-powered automation, UI/UX design, and branding — delivering solutions that are engineered to scale and designed to stand out."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						y: 30
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: {
						once: true,
						amount: .3
					},
					transition: {
						duration: .7,
						delay: .1
					},
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: secondimg_default,
						alt: "Hand holding a glowing digital card",
						loading: "lazy",
						className: "w-48 max-w-full sm:w-56 md:w-64 object-contain drop-shadow-2xl",
						style: { filter: "drop-shadow(0 0 30px rgba(15,7,24,0.4))" }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						y: 30
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: {
						once: true,
						amount: .3
					},
					transition: {
						duration: .7,
						delay: .2
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-white/90 md:text-base",
						children: "Our approach goes beyond development. We become your technology partner, working closely with your team to transform ideas into meaningful digital experiences. Every project is driven by innovation, attention to detail, and a commitment to quality — ensuring that every website, application, or brand we create not only looks exceptional but also performs flawlessly and supports long-term business growth."
					})
				})
			]
		})]
	});
}
function CTABanner() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden py-20 md:py-32",
		style: { background: "#0d0d10" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 z-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					autoPlay: true,
					muted: true,
					loop: true,
					playsInline: true,
					className: "h-full w-full object-cover opacity-25",
					style: { mixBlendMode: "screen" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
						src: "https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-network-animation-5798-large.mp4",
						type: "video/mp4"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-[#0d0d10] via-transparent to-[#0d0d10]" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-center justify-center z-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[350px] w-[700px] rounded-full bg-[#7E52D9]/25 blur-[120px]" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 20
				},
				whileInView: {
					opacity: 1,
					y: 0
				},
				viewport: { once: true },
				transition: { duration: .7 },
				className: "relative z-10 mx-auto max-w-4xl px-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl leading-tight",
					children: ["Build Your online presence ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "bg-gradient-to-r from-[#C49EFF] via-[#E0CFFF] to-white bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(168,130,255,0.5)]",
						children: "TODAY!"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "#contact",
						className: "group relative inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-gradient-to-r from-[#7E52D9] via-[#8A5CF5] to-[#A882FF] px-10 py-4 text-base font-bold text-white shadow-[0_0_30px_rgba(138,92,245,0.6)] transition-all duration-300 hover:scale-105 hover:shadow-[0_0_50px_rgba(168,130,255,0.9)] hover:border-white/40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Contact Us" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							width: "18",
							height: "18",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2.5",
							strokeLinecap: "round",
							strokeLinejoin: "round",
							className: "transition-transform duration-300 group-hover:translate-x-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "5",
								y1: "12",
								x2: "19",
								y2: "12"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "12 5 19 12 12 19" })]
						})]
					})
				})]
			})
		]
	});
}
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "services",
		className: "relative overflow-hidden py-24 md:py-32",
		style: { background: "#0d0d10" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-0 top-1/2 h-[600px] w-[600px] -translate-y-1/2 -translate-x-1/2 rounded-full bg-[#7E52D9]/10 blur-[120px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute right-0 top-0 h-[600px] w-[600px] translate-x-1/3 -translate-y-1/3 rounded-full bg-[#A86CFF]/10 blur-[120px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-6 md:px-10 grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-8 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						x: -30
					},
					whileInView: {
						opacity: 1,
						x: 0
					},
					viewport: { once: true },
					transition: {
						duration: .8,
						ease: "easeOut"
					},
					className: "flex flex-col items-start text-left z-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[#A86CFF] text-sm font-bold tracking-widest uppercase mb-4",
							children: "Services"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl sm:text-5xl lg:text-5xl font-extrabold text-white leading-[1.1] mb-6",
							children: "Professional Development and Branding Services"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-white/60 text-lg mb-8 max-w-lg leading-relaxed",
							children: "Everything you need to build, launch, and grow your digital presence — crafted with precision and passion."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-3 mb-10",
							children: [
								"Web / App Development",
								"Backend Development",
								"UI/UX Design / Branding",
								"AI Automation"
							].map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									width: "18",
									height: "18",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "#C49EFF",
									strokeWidth: "3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M5 13l4 4L19 7",
										strokeLinecap: "round",
										strokeLinejoin: "round"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white font-semibold",
									children: service
								})]
							}, service))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#contact",
							className: "group flex items-center gap-4 text-white font-bold text-lg hover:text-[#A86CFF] transition-colors mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative",
								children: ["Explore more", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 -bottom-1 w-full h-[2px] bg-white group-hover:bg-[#A86CFF] transition-colors" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 h-8 rounded-full bg-white group-hover:bg-[#A86CFF] transition-colors flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									width: "14",
									height: "14",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "3",
									className: "text-black group-hover:text-white",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 12h14M12 5l7 7-7 7" })
								})
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						scale: .95
					},
					whileInView: {
						opacity: 1,
						scale: 1
					},
					viewport: { once: true },
					transition: {
						duration: 1,
						delay: .2
					},
					className: "relative h-[500px] sm:h-[650px] w-full mt-10 lg:mt-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute top-0 left-0 w-[55%] h-[45%] rounded-3xl overflow-hidden shadow-2xl border border-white/10 z-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&q=80",
								alt: "Web and App Development code",
								className: "w-full h-full object-cover opacity-80 mix-blend-luminosity hover:mix-blend-normal hover:opacity-100 transition-all duration-500"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-[#0d0d10]/60 to-transparent" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute top-[20%] right-0 w-[45%] h-[55%] rounded-3xl overflow-hidden shadow-[0_30px_60px_rgba(0,0,0,0.8)] border border-white/10 z-20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80",
								alt: "UI/UX Design tools",
								className: "w-full h-full object-cover opacity-90 mix-blend-luminosity hover:mix-blend-normal hover:opacity-100 transition-all duration-500"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-[#7E52D9]/40 to-transparent mix-blend-overlay" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute bottom-0 left-[5%] w-[60%] h-[40%] rounded-3xl overflow-hidden shadow-2xl border border-white/10 z-30",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=800&q=80",
								alt: "AI and Automation visualization",
								className: "w-full h-full object-cover opacity-80 mix-blend-luminosity hover:mix-blend-normal hover:opacity-100 transition-all duration-500"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-[#0d0d10]/60 to-transparent" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute top-[50%] left-[55%] -translate-x-1/2 -translate-y-1/2 z-40 flex items-center justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								animate: { rotate: 360 },
								transition: {
									duration: 15,
									repeat: Infinity,
									ease: "linear"
								},
								className: "relative w-36 h-36 rounded-full bg-white flex items-center justify-center shadow-[0_0_30px_rgba(168,108,255,0.4)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 100 100",
									className: "w-full h-full p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										id: "circlePath",
										d: "M 50, 50 m -35, 0 a 35,35 0 1,1 70,0 a 35,35 0 1,1 -70,0",
										fill: "none"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
										fill: "#000",
										fontSize: "11.5",
										fontWeight: "bold",
										letterSpacing: "2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textPath", {
											href: "#circlePath",
											startOffset: "0%",
											children: "BEYOND YOUR IMAGINATION •"
										})
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute w-12 h-12 bg-[#0F0718] rounded-full flex items-center justify-center border-2 border-white shadow-inner",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display font-black text-white text-lg",
									children: "B"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute bottom-0 right-[15%] hidden lg:flex flex-col items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-[1px] h-20 bg-gradient-to-b from-transparent via-white/40 to-white/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-6 h-9 rounded-full border-2 border-white flex justify-center p-1 opacity-80",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									animate: { y: [
										0,
										10,
										0
									] },
									transition: {
										duration: 1.5,
										repeat: Infinity,
										ease: "easeInOut"
									},
									className: "w-1 h-2 bg-white rounded-full"
								})
							})]
						})
					]
				})]
			})
		]
	});
}
var steps = [
	{
		n: "01",
		phase: "Phase 01",
		title: "Discover & Strategize",
		subtitle: "Strategy + Planning",
		tags: [
			"Research",
			"Goal Setting",
			"Roadmap"
		],
		desc: "We begin by diving deep into your business model, target audience, and competitive landscape. Through collaborative discovery sessions, we architect a high-impact roadmap that aligns innovative AI technology with your long-term vision.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "26",
			height: "26",
			viewBox: "0 0 24 24",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "10"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" })]
		}),
		accent: "from-[#8A5CF5]/30 to-transparent"
	},
	{
		n: "02",
		phase: "Phase 02",
		title: "Design & Engineering",
		subtitle: "Build with Precision",
		tags: [
			"UI/UX Design",
			"Full-Stack Dev",
			"AI Automation"
		],
		desc: "Our engineers and designers transform concepts into state-of-the-art digital ecosystems. From luxury glassmorphic UI/UX and branding to robust full-stack architectures and AI automation, every component is crafted for elite performance.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "26",
			height: "26",
			viewBox: "0 0 24 24",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "16 18 22 12 16 6" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "8 6 2 12 8 18" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "14",
					y1: "4",
					x2: "10",
					y2: "20"
				})
			]
		}),
		accent: "from-[#A882FF]/30 to-transparent"
	},
	{
		n: "03",
		phase: "Phase 03",
		title: "Launch & Accelerate",
		subtitle: "Optimize for Growth",
		tags: [
			"Security Audit",
			"Deployment",
			"Growth Scalability"
		],
		desc: "Following rigorous security and stress testing, we execute a seamless cloud deployment. We continuously monitor real-world analytics and optimize infrastructure to guarantee effortless scaling as your enterprise expands.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "26",
			height: "26",
			viewBox: "0 0 24 24",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" })
			]
		}),
		accent: "from-[#C49EFF]/30 to-transparent"
	}
];
function Process() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "process",
		className: "relative overflow-hidden pt-16 pb-12 md:pt-24 md:pb-16",
		style: { background: "#0d0d10" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-1/4 top-1/2 h-[500px] w-[500px] -translate-y-1/2 -translate-x-1/2 rounded-full bg-[#6A38C2]/15 blur-[140px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute right-1/4 bottom-0 h-[500px] w-[500px] translate-x-1/4 rounded-full bg-[#8A5CF5]/15 blur-[140px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-6 md:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: { once: true },
					transition: { duration: .7 },
					className: "text-center max-w-3xl mx-auto mb-16 md:mb-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 px-3.5 py-1.5 mb-5 rounded-full border border-white/15 bg-white/5 backdrop-blur-md shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#A882FF] animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold tracking-wide text-white/80 uppercase",
								children: "How We Work"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-[54px] leading-[1.08] mb-4",
							children: ["Our Proven ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "bg-gradient-to-r from-white via-[#E0CFFF] to-[#A882FF] bg-clip-text text-transparent",
								children: "Agency Process"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-white/60 text-base sm:text-lg",
							children: "A transparent, engineering-first methodology designed to take your ambitious vision from concept to market-leading reality."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 lg:grid-cols-3 gap-8 relative z-10",
					children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 30
						},
						whileInView: {
							opacity: 1,
							y: 0
						},
						viewport: {
							once: true,
							amount: .2
						},
						transition: {
							duration: .6,
							delay: i * .15
						},
						className: "group relative rounded-3xl border border-white/15 bg-gradient-to-b from-white/[0.08] to-white/[0.02] p-8 sm:p-9 backdrop-blur-xl transition-all duration-500 hover:-translate-y-2 hover:border-[#A882FF]/50 hover:shadow-[0_20px_50px_rgba(168,130,255,0.2)] flex flex-col justify-between overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `pointer-events-none absolute -top-24 -right-24 h-48 w-48 rounded-full bg-gradient-to-br ${s.accent} blur-2xl group-hover:scale-150 transition-transform duration-700` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex h-9 items-center justify-center rounded-xl bg-gradient-to-r from-[#8A5CF5] to-[#A882FF] px-3.5 text-xs font-black text-black shadow-[0_0_15px_rgba(168,130,255,0.4)]",
											children: s.n
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold uppercase tracking-widest text-white/50 group-hover:text-white/80 transition-colors",
											children: s.phase
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-12 w-12 items-center justify-center rounded-2xl border border-white/15 bg-white/5 text-[#C49EFF] group-hover:scale-110 group-hover:border-[#A882FF]/40 group-hover:bg-[#A882FF]/15 transition-all duration-300 shadow-sm",
										children: s.icon
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl sm:text-3xl font-bold text-white mb-1 group-hover:text-[#E0CFFF] transition-colors",
									children: s.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-[#A882FF] mb-6",
									children: s.subtitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-white/70 leading-relaxed mb-8",
									children: s.desc
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-6 border-t border-white/10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-bold uppercase tracking-widest text-white/40 mb-3.5",
									children: "Key Deliverables"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center gap-x-5 gap-y-2.5",
									children: s.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 group/tag",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-[#C49EFF] shadow-[0_0_8px_#C49EFF] group-hover/tag:scale-150 transition-transform" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-semibold text-white/75 group-hover/tag:text-white transition-colors tracking-wide",
											children: tag
										})]
									}, tag))
								})]
							})
						]
					}, s.n))
				})]
			})
		]
	});
}
function Contact() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [formData, setFormData] = (0, import_react.useState)({
		fullname: "",
		email: "",
		company: "",
		phone: "",
		message: ""
	});
	const handleChange = (e) => {
		const { name, value } = e.target;
		if (name === "phone") {
			const numericVal = value.replace(/\D/g, "").slice(0, 10);
			setFormData({
				...formData,
				phone: numericVal
			});
		} else setFormData({
			...formData,
			[name]: value
		});
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (formData.phone.length !== 10) {
			alert("Please enter a valid 10-digit phone number.");
			return;
		}
		setLoading(true);
		try {
			await submitContactForm({ data: formData });
			setSent(true);
			setFormData({
				fullname: "",
				email: "",
				company: "",
				phone: "",
				message: ""
			});
		} catch (error) {
			console.error("Failed to submit form", error);
			alert(error?.message || "Failed to submit the form. Please make sure all fields are valid.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "contact",
		className: "relative overflow-hidden py-12 md:py-16",
		style: { background: "#0d0d10" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 z-0 overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=2000&q=80",
						alt: "High Speed Earth Network Connections",
						className: "h-full w-full object-cover object-center opacity-70"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						autoPlay: true,
						muted: true,
						loop: true,
						playsInline: true,
						className: "absolute inset-0 h-full w-full object-cover object-center opacity-75",
						style: { mixBlendMode: "screen" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
							src: "https://assets.mixkit.co/videos/preview/mixkit-globe-animation-with-digital-network-connections-31588-large.mp4",
							type: "video/mp4"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-[#0d0d10] via-transparent to-[#0d0d10] opacity-80" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[#0d0d10]/30" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-0 top-1/3 z-0 h-[500px] w-[500px] -translate-x-1/3 rounded-full bg-[#5d28ab]/20 blur-[130px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute right-0 bottom-0 z-0 h-[600px] w-[600px] translate-x-1/3 rounded-full bg-[#8A5CF5]/15 blur-[150px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 mx-auto max-w-7xl w-full px-6 md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							x: -30
						},
						whileInView: {
							opacity: 1,
							x: 0
						},
						viewport: { once: true },
						transition: { duration: .7 },
						className: "lg:col-span-5 flex flex-col justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 px-3 py-1 mb-3.5 rounded-full border border-white/15 bg-white/5 backdrop-blur-md shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#A882FF] animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold tracking-wide text-white/80 uppercase",
									children: "Get In Touch"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-3xl sm:text-4xl lg:text-[42px] xl:text-[46px] font-extrabold leading-[1.06] tracking-tight text-white mb-3",
								children: [
									"Let's Build ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "bg-gradient-to-r from-white via-[#E0CFFF] to-[#A882FF] bg-clip-text text-transparent",
										children: "Something Extraordinary."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-white/70 text-xs sm:text-sm leading-relaxed mb-6 max-w-md",
								children: "Have a vision, question, or ambitious project? Partner with our team of AI and design engineers to bring your ideas to life."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:support@beyondyourimagination.shop",
									className: "group flex items-center gap-3.5 p-3 sm:p-3.5 rounded-xl border border-white/10 bg-white/[0.03] hover:bg-white/[0.07] hover:border-white/25 transition-all duration-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-[#7E52D9]/40 to-[#A882FF]/10 border border-white/15 text-[#C49EFF] group-hover:scale-110 transition-transform",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											width: "18",
											height: "18",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2",
											strokeLinecap: "round",
											strokeLinejoin: "round",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "22,6 12,13 2,6" })]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-medium text-white/50 uppercase tracking-wider mb-0.5",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold text-white group-hover:text-[#C49EFF] transition-colors break-all",
										children: "support@beyondyourimagination.shop"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3.5 p-3 sm:p-3.5 rounded-xl border border-white/10 bg-white/[0.03]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-[#7E52D9]/40 to-[#A882FF]/10 border border-white/15 text-[#C49EFF]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											width: "18",
											height: "18",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2",
											strokeLinecap: "round",
											strokeLinejoin: "round",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: "12",
												cy: "10",
												r: "3"
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-medium text-white/50 uppercase tracking-wider mb-0.5",
										children: "Location"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold text-white",
										children: "Patna, Bihar"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-1 flex flex-wrap items-center gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://instagram.com",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/80 hover:bg-white/15 hover:text-white transition-all",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											width: "12",
											height: "12",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: "2",
													y: "2",
													width: "20",
													height: "20",
													rx: "5",
													ry: "5"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
													x1: "17.5",
													y1: "6.5",
													x2: "17.51",
													y2: "6.5"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "@byi_agency" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://linkedin.com",
										target: "_blank",
										rel: "noopener noreferrer",
										className: "inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/80 hover:bg-white/15 hover:text-white transition-all",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											width: "12",
											height: "12",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: "2",
													y: "9",
													width: "4",
													height: "12"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
													cx: "4",
													cy: "4",
													r: "2"
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "beyondyourimagination" })]
									})]
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: {
							opacity: 0,
							x: 30
						},
						whileInView: {
							opacity: 1,
							x: 0
						},
						viewport: { once: true },
						transition: {
							duration: .7,
							delay: .15
						},
						className: "lg:col-span-7",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSubmit,
							className: "relative rounded-2xl p-5 sm:p-7 border border-white/15 bg-gradient-to-b from-white/[0.07] to-white/[0.02] backdrop-blur-xl shadow-[0_0_50px_rgba(138,92,245,0.12)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl sm:text-2xl font-bold text-white mb-1",
										children: "Send us a Message"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-white/60",
										children: "Fill out the form below and our team will get back to you within 24 hours."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5 mb-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "fullname",
										className: "block text-[10px] font-semibold uppercase tracking-wider text-white/70 mb-1.5",
										children: ["Full Name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#A882FF]",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "fullname",
										name: "fullname",
										type: "text",
										placeholder: "John Doe",
										value: formData.fullname,
										onChange: handleChange,
										required: true,
										className: "w-full rounded-lg border border-white/15 bg-white/5 px-3.5 py-2.5 text-xs text-white placeholder-white/30 outline-none transition-all focus:border-[#A882FF] focus:bg-white/10 focus:ring-1 focus:ring-[#A882FF]"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "email",
										className: "block text-[10px] font-semibold uppercase tracking-wider text-white/70 mb-1.5",
										children: ["Email Address ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#A882FF]",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "email",
										name: "email",
										type: "email",
										placeholder: "john@example.com",
										value: formData.email,
										onChange: handleChange,
										required: true,
										className: "w-full rounded-lg border border-white/15 bg-white/5 px-3.5 py-2.5 text-xs text-white placeholder-white/30 outline-none transition-all focus:border-[#A882FF] focus:bg-white/10 focus:ring-1 focus:ring-[#A882FF]"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5 mb-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "company",
										className: "block text-[10px] font-semibold uppercase tracking-wider text-white/70 mb-1.5",
										children: "Company Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "company",
										name: "company",
										type: "text",
										placeholder: "Your Company Ltd.",
										value: formData.company,
										onChange: handleChange,
										className: "w-full rounded-lg border border-white/15 bg-white/5 px-3.5 py-2.5 text-xs text-white placeholder-white/30 outline-none transition-all focus:border-[#A882FF] focus:bg-white/10 focus:ring-1 focus:ring-[#A882FF]"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "phone",
										className: "block text-[10px] font-semibold uppercase tracking-wider text-white/70 mb-1.5",
										children: ["Phone Number ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#A882FF]",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "phone",
										name: "phone",
										type: "tel",
										maxLength: 10,
										minLength: 10,
										pattern: "[0-9]{10}",
										placeholder: "e.g. 9876543210",
										value: formData.phone,
										onChange: handleChange,
										required: true,
										className: "w-full rounded-lg border border-white/15 bg-white/5 px-3.5 py-2.5 text-xs text-white placeholder-white/30 outline-none transition-all focus:border-[#A882FF] focus:bg-white/10 focus:ring-1 focus:ring-[#A882FF]"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "message",
										className: "block text-[10px] font-semibold uppercase tracking-wider text-white/70 mb-1.5",
										children: "Project Details / Message"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "message",
										name: "message",
										rows: 2,
										placeholder: "Tell us about your project requirements or goals...",
										value: formData.message,
										onChange: handleChange,
										className: "w-full rounded-lg border border-white/15 bg-white/5 px-3.5 py-2.5 text-xs text-white placeholder-white/30 outline-none transition-all focus:border-[#A882FF] focus:bg-white/10 focus:ring-1 focus:ring-[#A882FF] resize-none"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: loading || sent,
									className: "w-full rounded-xl bg-gradient-to-r from-white via-white to-[#E0CFFF] py-3 text-sm font-bold text-black shadow-[0_0_20px_rgba(255,255,255,0.2)] transition-all duration-300 hover:shadow-[0_0_35px_rgba(168,130,255,0.5)] hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-70 disabled:hover:translate-y-0 flex items-center justify-center gap-2",
									children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sending Message..." }) : sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#2e7d32] font-extrabold",
										children: "✓ Message Sent Successfully!"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Submit Inquiry" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										width: "16",
										height: "16",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											strokeLinecap: "round",
											strokeLinejoin: "round",
											d: "M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
										})
									})] })
								})
							]
						})
					})]
				})
			})
		]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative overflow-hidden border-t border-white/10 pt-16 pb-12 text-white",
		style: { background: "#0b0b0e" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-1/2 top-0 h-[300px] w-[800px] -translate-x-1/2 rounded-full bg-[#7E52D9]/15 blur-[120px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-7xl px-6 md:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-16 rounded-3xl border border-white/15 bg-gradient-to-r from-white/[0.07] via-[#8A5CF5]/10 to-white/[0.05] p-8 sm:p-10 backdrop-blur-xl shadow-[0_0_60px_rgba(138,92,245,0.12)] flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-10 -bottom-10 h-40 w-40 rounded-full bg-[#A882FF]/20 blur-2xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center md:text-left z-10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-block text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-2",
									children: "Next-Generation Digital Agency"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl sm:text-3xl font-extrabold text-white",
									children: "Ready to elevate your digital presence?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-white/70 max-w-lg",
									children: "Let's collaborate to build cutting-edge AI software and breathtaking web experiences tailored to your vision."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-center gap-3.5 z-10 shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "https://beyondyourimagination.shop",
								className: "inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-semibold text-white backdrop-blur transition-all hover:bg-white/20 hover:border-white/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Visit Main Store" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									width: "14",
									height: "14",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contact",
								className: "inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-white via-white to-[#E0CFFF] px-6 py-3 text-sm font-bold text-black shadow-[0_0_25px_rgba(255,255,255,0.25)] transition-all hover:shadow-[0_0_40px_rgba(168,130,255,0.6)] hover:-translate-y-0.5",
								children: "Start Your Project"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-4 flex flex-col items-center sm:items-start text-center sm:text-left justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center sm:justify-start gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-xl bg-gradient-to-br from-white/20 to-white/5 border border-white/20 shadow-[0_0_15px_rgba(168,130,255,0.3)] shrink-0 p-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: logo_default,
										alt: "Beyond Your Imagination Logo",
										className: "h-full w-full object-contain",
										style: { filter: "brightness(1.25) drop-shadow(0 0 6px rgba(255,255,255,0.4))" }
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-display text-base sm:text-lg font-extrabold text-white tracking-tight leading-none",
									children: ["Beyond Your ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#C49EFF]",
										children: "Imagination"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 sm:mt-4 max-w-sm text-xs sm:text-sm leading-relaxed text-white/60 mx-auto sm:mx-0",
								children: "Architecting luxury digital products, AI solutions, and high-conversion web ecosystems that push boundaries beyond imagination."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 sm:mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:support@beyondyourimagination.shop",
									className: "inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-xs font-medium text-white/80 hover:border-white/25 hover:text-[#C49EFF] transition-colors break-all sm:break-normal max-w-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										className: "shrink-0",
										width: "14",
										height: "14",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "22,6 12,13 2,6" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "support@beyondyourimagination.shop" })]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-6 sm:gap-8 lg:col-span-5 lg:pl-6 text-center sm:text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center sm:items-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-[11px] sm:text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-3.5",
									children: "Navigation"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2.5 text-xs sm:text-sm font-medium text-white/70 flex flex-col items-center sm:items-start",
									children: [
										"Home",
										"About",
										"Services",
										"Process",
										"Contact"
									].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: `#${item.toLowerCase()}`,
										className: "group inline-flex items-center justify-center sm:justify-start gap-1.5 hover:text-white transition-colors",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#A882FF] opacity-60 group-hover:opacity-100 transition-opacity",
											children: "›"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
									}) }, item))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center sm:items-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-[11px] sm:text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-3.5",
									children: "Ecosystem"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "space-y-2.5 text-xs sm:text-sm font-medium text-white/70 flex flex-col items-center sm:items-start",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "https://beyondyourimagination.shop",
											className: "hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1 group",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#A882FF] opacity-60 group-hover:opacity-100 transition-opacity",
													children: "›"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Main Website" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
													width: "11",
													height: "11",
													viewBox: "0 0 24 24",
													fill: "none",
													stroke: "currentColor",
													strokeWidth: "2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
														strokeLinecap: "round",
														strokeLinejoin: "round",
														d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"
													})
												})
											]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "#services",
											className: "hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#A882FF] opacity-60",
												children: "›"
											}), " AI Engineering"]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "#services",
											className: "hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#A882FF] opacity-60",
												children: "›"
											}), " UI/UX Design"]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "#contact",
											className: "hover:text-white transition-colors inline-flex items-center justify-center sm:justify-start gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#A882FF] opacity-60",
												children: "›"
											}), " Client Support"]
										}) })
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-3 flex flex-col items-center sm:items-start text-center sm:text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-[11px] sm:text-xs font-bold uppercase tracking-widest text-[#C49EFF] mb-3.5",
									children: "Connect With Us"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-white/60 mb-4 leading-relaxed max-w-xs mx-auto sm:mx-0",
									children: "Follow our latest work, insights, and innovations across social media."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center sm:justify-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "https://www.instagram.com/byi_agency/",
										target: "_blank",
										rel: "noopener noreferrer",
										"aria-label": "Instagram",
										className: "flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-white/80 transition-all duration-300 hover:scale-110 hover:border-[#A882FF] hover:bg-[#A882FF]/20 hover:text-white hover:shadow-[0_0_20px_rgba(168,130,255,0.5)]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											width: "18",
											height: "18",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: "2",
													y: "2",
													width: "20",
													height: "20",
													rx: "5",
													ry: "5"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
													x1: "17.5",
													y1: "6.5",
													x2: "17.51",
													y2: "6.5"
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "https://www.facebook.com/profile.php?fb_profile_edit_entry_point=%7B%22click_point%22%3A%22edit_profile_button%22%2C%22feature%22%3A%22profile_header%22%7D&id=61591354119710&sk=about",
										target: "_blank",
										rel: "noopener noreferrer",
										"aria-label": "Facebook",
										className: "flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-white/80 transition-all duration-300 hover:scale-110 hover:border-[#A882FF] hover:bg-[#A882FF]/20 hover:text-white hover:shadow-[0_0_20px_rgba(168,130,255,0.5)]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											width: "18",
											height: "18",
											viewBox: "0 0 24 24",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" })
										})
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-12 sm:mt-14 border-t border-white/10 pt-6 sm:pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left text-xs font-medium text-white/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Beyond Your Imagination. All rights reserved."
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-center gap-5 sm:gap-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#",
								className: "hover:text-white transition-colors",
								children: "Privacy Policy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#",
								className: "hover:text-white transition-colors",
								children: "Terms of Service"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#",
								className: "hover:text-white transition-colors",
								children: "Security"
							})
						]
					})]
				})
			]
		})]
	});
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen overflow-x-hidden bg-[#0F0718] text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTABanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Process, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { Index as component };

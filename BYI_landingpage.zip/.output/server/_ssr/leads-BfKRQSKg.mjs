import { o as __toESM } from "../_runtime.mjs";
import { i as verifyAdminAuth, r as updateLeadStatus, t as getLeads } from "./contact--Ca3KR-h.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leads-BfKRQSKg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLeadsDashboard() {
	const [password, setPassword] = (0, import_react.useState)("");
	const [inputPass, setInputPass] = (0, import_react.useState)("");
	const [isAuthenticated, setIsAuthenticated] = (0, import_react.useState)(false);
	const [authError, setAuthError] = (0, import_react.useState)("");
	const [authLoading, setAuthLoading] = (0, import_react.useState)(false);
	const [leads, setLeads] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("All");
	const [updatingId, setUpdatingId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const savedPass = sessionStorage.getItem("byi_admin_key");
		if (savedPass) {
			setPassword(savedPass);
			setIsAuthenticated(true);
			fetchLeadsData(savedPass);
		} else setLoading(false);
	}, []);
	const handleLogin = async (e) => {
		e.preventDefault();
		setAuthLoading(true);
		setAuthError("");
		try {
			await verifyAdminAuth({ data: { password: inputPass } });
			sessionStorage.setItem("byi_admin_key", inputPass);
			setPassword(inputPass);
			setIsAuthenticated(true);
			fetchLeadsData(inputPass);
		} catch (err) {
			setAuthError("Incorrect security key. Access denied.");
		} finally {
			setAuthLoading(false);
		}
	};
	const handleLogout = () => {
		sessionStorage.removeItem("byi_admin_key");
		setIsAuthenticated(false);
		setPassword("");
		setLeads([]);
	};
	const fetchLeadsData = async (passKey) => {
		setLoading(true);
		try {
			const data = await getLeads({ data: { password: passKey } });
			setLeads(data);
		} catch (error) {
			console.error("Failed to load leads:", error);
		} finally {
			setLoading(false);
		}
	};
	const handleStatusChange = async (id, newStatus) => {
		setUpdatingId(id);
		try {
			await updateLeadStatus({ data: {
				id,
				status: newStatus,
				password
			} });
			setLeads((prev) => prev.map((l) => l._id === id ? {
				...l,
				status: newStatus,
				pushedToMainStore: newStatus === "Interested" || newStatus === "Converted" ? true : l.pushedToMainStore
			} : l));
		} catch (error) {
			console.error("Status update failed:", error);
			alert("Failed to update status.");
		} finally {
			setUpdatingId(null);
		}
	};
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#0a0a0c] text-white flex items-center justify-center p-4 relative overflow-hidden font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-1/2 top-1/2 h-[450px] w-[450px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#8A5CF5]/15 blur-[120px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 w-full max-w-md rounded-3xl border border-white/15 bg-gradient-to-b from-white/[0.08] to-white/[0.02] p-8 sm:p-10 backdrop-blur-2xl shadow-[0_0_80px_rgba(138,92,245,0.2)] text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#8A5CF5] to-[#A882FF] text-black shadow-[0_0_25px_rgba(138,92,245,0.5)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						width: "24",
						height: "24",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2.5",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "3",
							y: "11",
							width: "18",
							height: "11",
							rx: "2",
							ry: "2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M7 11V7a5 5 0 0 1 10 0v4" })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-extrabold text-white tracking-tight mb-2",
					children: "Secure Leads Portal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-white/60 mb-6 leading-relaxed",
					children: "Enter your admin security key to unlock incoming Meta Ads customer inquiries and synchronize data."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleLogin,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							placeholder: "Enter Admin Password...",
							value: inputPass,
							onChange: (e) => setInputPass(e.target.value),
							required: true,
							className: "w-full rounded-xl border border-white/20 bg-black/40 px-4 py-3.5 text-center text-sm font-semibold text-white placeholder-white/30 outline-none transition-all focus:border-[#A882FF] focus:ring-1 focus:ring-[#A882FF]"
						}) }),
						authError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-rose-400 bg-rose-500/10 border border-rose-500/20 py-2 rounded-lg",
							children: authError
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: authLoading,
							className: "w-full rounded-xl bg-gradient-to-r from-white via-white to-[#E0CFFF] py-3.5 text-sm font-bold text-black shadow-[0_0_25px_rgba(255,255,255,0.25)] hover:shadow-[0_0_35px_rgba(168,130,255,0.5)] transition-all flex items-center justify-center gap-2",
							children: authLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-black border-t-transparent" }), "Verifying Security Key..."]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unlock Portal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "16",
								height: "16",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 12h14M12 5l7 7-7 7" })
							})] })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 pt-6 border-t border-white/10 flex items-center justify-between text-[11px] text-white/40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Encrypted Connection" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "hover:text-white transition-colors",
						children: "← Return Home"
					})]
				})
			]
		})]
	});
	const filteredLeads = leads.filter((lead) => {
		const matchesSearch = lead.fullname.toLowerCase().includes(searchTerm.toLowerCase()) || lead.email.toLowerCase().includes(searchTerm.toLowerCase()) || lead.phone.includes(searchTerm) || lead.company.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesStatus = statusFilter === "All" || lead.status === statusFilter;
		return matchesSearch && matchesStatus;
	});
	const totalLeads = leads.length;
	const newLeads = leads.filter((l) => l.status === "New").length;
	const interestedLeads = leads.filter((l) => l.status === "Interested").length;
	const convertedLeads = leads.filter((l) => l.status === "Converted").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#0a0a0c] text-white font-sans selection:bg-[#8A5CF5] selection:text-white pb-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-50 border-b border-white/10 bg-[#0a0a0c]/80 backdrop-blur-xl px-6 py-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#8A5CF5] to-[#A882FF] font-bold text-black shadow-[0_0_20px_rgba(138,92,245,0.4)]",
						children: "✦"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-base font-bold tracking-tight text-white sm:text-lg",
						children: ["BYI Agency ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[#A882FF]",
							children: "Leads Portal"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-white/50",
						children: "Meta Ads Lead Management & Main Website Sync"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/",
							className: "rounded-lg border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-semibold text-white/80 hover:bg-white/10 hover:text-white transition-all",
							children: "← Landing Page"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => fetchLeadsData(password),
							disabled: loading,
							className: "rounded-lg bg-gradient-to-r from-[#8A5CF5] to-[#A882FF] px-3.5 py-2 text-xs font-bold text-black hover:opacity-90 transition-opacity flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								width: "14",
								height: "14",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67" })
							}), "Refresh"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: handleLogout,
							className: "rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-500/20 transition-all",
							children: "Lock / Logout"
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-7xl px-4 sm:px-6 pt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-white/50 mb-1",
								children: "Total Meta Leads"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl sm:text-3xl font-extrabold text-white",
								children: totalLeads
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-blue-500/20 bg-blue-500/[0.05] p-5 backdrop-blur-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-blue-400 mb-1",
								children: "New Inquiries"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl sm:text-3xl font-extrabold text-blue-300",
								children: newLeads
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-amber-500/20 bg-amber-500/[0.05] p-5 backdrop-blur-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1",
								children: "Interested Leads"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl sm:text-3xl font-extrabold text-amber-300",
								children: interestedLeads
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.05] p-5 backdrop-blur-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1",
								children: "Synced to Main Store"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl sm:text-3xl font-extrabold text-emerald-300",
								children: convertedLeads + interestedLeads
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 max-w-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "Search leads by name, phone, email or company...",
							value: searchTerm,
							onChange: (e) => setSearchTerm(e.target.value),
							className: "w-full rounded-xl border border-white/15 bg-white/5 pl-10 pr-4 py-2.5 text-xs text-white placeholder-white/40 outline-none focus:border-[#A882FF] focus:bg-white/10"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40",
							width: "16",
							height: "16",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "11",
								cy: "11",
								r: "8"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: "21",
								y1: "21",
								x2: "16.65",
								y2: "16.65"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0",
						children: [
							"All",
							"New",
							"Contacted",
							"Interested",
							"Converted"
						].map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setStatusFilter(status),
							className: `rounded-lg px-3 py-1.5 text-xs font-semibold transition-all shrink-0 ${statusFilter === status ? "bg-[#8A5CF5] text-white shadow-[0_0_15px_rgba(138,92,245,0.4)]" : "border border-white/10 bg-white/5 text-white/70 hover:bg-white/10 hover:text-white"}`,
							children: status
						}, status))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-xl overflow-hidden shadow-2xl",
					children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-20 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "inline-block h-8 w-8 animate-spin rounded-full border-2 border-[#8A5CF5] border-t-transparent mb-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-white/60 font-medium",
							children: "Loading Meta Ads leads..."
						})]
					}) : filteredLeads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-16 text-center px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-white/70 mb-1",
							children: "No leads found"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-white/40",
							children: "When visitors submit inquiries from your Meta Ads, they will appear here."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left border-collapse",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-white/10 bg-white/[0.03] text-[10px] font-bold uppercase tracking-wider text-white/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3.5 px-4",
										children: "Customer Details"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3.5 px-4",
										children: "Contact Info"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3.5 px-4",
										children: "Project Message"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3.5 px-4",
										children: "Date Submitted"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3.5 px-4 text-center",
										children: "Lead Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3.5 px-4 text-center",
										children: "Main Store Sync"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "divide-y divide-white/10 text-xs",
								children: filteredLeads.map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-white/[0.04] transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-4 px-4 font-medium text-white",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-sm text-white",
												children: lead.fullname
											}), lead.company && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-[#A882FF] mt-0.5 font-semibold",
												children: lead.company
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-4 px-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-white/90 mb-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
													width: "13",
													height: "13",
													viewBox: "0 0 24 24",
													fill: "none",
													stroke: "#A882FF",
													strokeWidth: "2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `tel:${lead.phone}`,
													className: "hover:underline font-mono font-semibold",
													children: lead.phone
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-white/60",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
													width: "13",
													height: "13",
													viewBox: "0 0 24 24",
													fill: "none",
													stroke: "currentColor",
													strokeWidth: "2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "22,6 12,13 2,6" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `mailto:${lead.email}`,
													className: "hover:underline break-all",
													children: lead.email
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-4 px-4 max-w-xs text-white/70 leading-relaxed",
											children: lead.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "line-clamp-2",
												children: lead.message
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "italic text-white/30",
												children: "No details provided"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-4 px-4 whitespace-nowrap text-white/60",
											children: [new Date(lead.createdAt).toLocaleDateString("en-US", {
												month: "short",
												day: "numeric",
												year: "numeric"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-white/40",
												children: new Date(lead.createdAt).toLocaleTimeString([], {
													hour: "2-digit",
													minute: "2-digit"
												})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-4 px-4 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: lead.status,
												disabled: updatingId === lead._id,
												onChange: (e) => handleStatusChange(lead._id, e.target.value),
												className: `rounded-full px-3 py-1 font-bold text-[11px] outline-none cursor-pointer transition-all ${lead.status === "New" ? "bg-blue-500/20 text-blue-300 border border-blue-500/30" : lead.status === "Contacted" ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" : lead.status === "Interested" ? "bg-amber-500/20 text-amber-300 border border-amber-500/30" : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.3)]"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "New",
														className: "bg-[#121216] text-white",
														children: "New"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Contacted",
														className: "bg-[#121216] text-white",
														children: "Contacted"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Interested",
														className: "bg-[#121216] text-white",
														children: "Interested ⭐"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Converted",
														className: "bg-[#121216] text-white",
														children: "Converted ✓"
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-4 px-4 text-center",
											children: lead.pushedToMainStore || lead.status === "Interested" || lead.status === "Converted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "inline-flex items-center gap-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-1 text-[10px] font-bold text-emerald-300",
												children: "✦ Synced to Main Store"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-white/40 italic",
												children: "Pending status change"
											})
										})
									]
								}, lead._id))
							})]
						})
					})
				})
			]
		})]
	});
}
//#endregion
export { AdminLeadsDashboard as component };

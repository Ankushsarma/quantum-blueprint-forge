//#region node_modules/.nitro/vite/services/ssr/assets/empty-plugin-adapters-Dd2kurwZ.js
var pluginSerializationAdapters = [];
var hasPluginAdapters = false;
//#endregion
export { hasPluginAdapters, pluginSerializationAdapters };

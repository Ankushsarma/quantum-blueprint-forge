//#region node_modules/.nitro/vite/services/ssr/assets/logo-aqA3rk2Z.js
var logo_default = "/assets/logo-gJGs9E64.png";
//#endregion
export { logo_default as t };

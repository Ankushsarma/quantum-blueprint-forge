import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-BfDQLD5K.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-D-fSknPv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact--Ca3KR-h.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var submitContactForm = createServerFn({ method: "POST" }).validator((data) => {
	const cleanPhone = data.phone?.replace(/\D/g, "");
	if (!cleanPhone || cleanPhone.length !== 10) throw new Error("Phone number must be exactly 10 digits");
	return {
		...data,
		phone: cleanPhone
	};
}).handler(createSsrRpc("4d0e05268a603875317a5113fa9eded1af11ddcd2ad1205d38fe8196605dae7e"));
var verifyAdminAuth = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("4791d1765c9018fdebb29c0efbd58e5e1711e4743b058ce7455d73dad5884a6e"));
var getLeads = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("4f53c207501d4b162bbfdf5f3882f657907c833cf629270a0c1bb06ae3b94ffd"));
var updateLeadStatus = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("9e6df912563b5e8f5318f93ce9c19aab0e6abfbd1bd3818331fecbaf7ca52eff"));
//#endregion
export { verifyAdminAuth as i, submitContactForm as n, updateLeadStatus as r, getLeads as t };

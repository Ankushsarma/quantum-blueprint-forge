//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-_ke8qGtl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/xampp/htdocs/byi/BYI-Agency/BYI_Landing_Page/src/routes/__root.tsx",
		children: ["/", "/admin/leads"],
		preloads: ["/assets/index-GL70j-uq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-GL70j-uq.js"
		} }]
	},
	"/": {
		filePath: "C:/xampp/htdocs/byi/BYI-Agency/BYI_Landing_Page/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-dKi_WQZ4.js", "/assets/contact-CzZ7-zqO.js"]
	},
	"/admin/leads": {
		filePath: "C:/xampp/htdocs/byi/BYI-Agency/BYI_Landing_Page/src/routes/admin/leads.tsx",
		children: void 0,
		preloads: ["/assets/leads-BYGCw31k.js", "/assets/contact-CzZ7-zqO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
